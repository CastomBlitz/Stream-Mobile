# Screen Stream
Запись экрана + RTMP-стрим + вставка видео в кадр + заставка/концовка.
1. Залей папку в репозиторий GitHub (ветка main).
2. Вкладка Actions -> Build APK -> дождись зелёной галочки.
3. Artifacts -> ScreenStream-debug-apk -> скачай, установи.
