package com.example.screenstream

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }

    private fun keep(u: Uri) {
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
    }

    private fun name(u: Uri?): String = u?.lastPathSegment?.substringAfterLast('/') ?: "не выбрано"

    @Composable
    fun Screen() {
        val live by StreamBus.live.collectAsState()
        val overlayOn by StreamBus.overlay.collectAsState()
        val status by StreamBus.status.collectAsState()

        var url by remember { mutableStateOf("") }
        var p1080 by remember { mutableStateOf(false) }
        var sysAudio by remember { mutableStateOf(Build.VERSION.SDK_INT >= 29) }
        var record by remember { mutableStateOf(false) }
        var intro by remember { mutableStateOf<Uri?>(null) }
        var outro by remember { mutableStateOf<Uri?>(null) }
        var clip by remember { mutableStateOf<Uri?>(null) }
        var size by remember { mutableFloatStateOf(40f) }
        var pos by remember { mutableIntStateOf(0) }
        var loop by remember { mutableStateOf(true) }

        val pickIntro = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { keep(it); intro = it } }
        val pickOutro = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { keep(it); outro = it } }
        val pickClip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { keep(it); clip = it } }

        val capture = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val dm = resources.displayMetrics
                val sw = dm.widthPixels
                val sh = dm.heightPixels
                val k = (if (p1080) 1080f else 720f) / minOf(sw, sh)
                val w = (sw * k).toInt() and 1.inv()
                val h = (sh * k).toInt() and 1.inv()
                val i = Intent(this, StreamService::class.java).setAction(StreamService.A_START)
                    .putExtra("code", r.resultCode)
                    .putExtra("data", data)
                    .putExtra("w", w).putExtra("h", h).putExtra("dpi", dm.densityDpi)
                    .putExtra("br", if (p1080) 6_000_000 else 3_500_000)
                    .putExtra("url", url.trim())
                    .putExtra("rec", record)
                    .putExtra("sysAudio", sysAudio)
                intro?.let { i.putExtra("intro", it.toString()) }
                outro?.let { i.putExtra("outro", it.toString()) }
                ContextCompat.startForegroundService(this, i)
            }
        }

        val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res[Manifest.permission.RECORD_AUDIO] == true) {
                val mpm = getSystemService(MediaProjectionManager::class.java)
                capture.launch(mpm.createScreenCaptureIntent())
            } else Toast.makeText(this, "Нужен доступ к микрофону/звуку", Toast.LENGTH_LONG).show()
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Screen Stream", style = MaterialTheme.typography.headlineMedium)
            Text("Статус: $status")

            OutlinedTextField(
                value = url, onValueChange = { url = it }, enabled = !live,
                label = { Text("RTMP-адрес + ключ (rtmp://.../ключ)") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Качество:", Modifier.weight(1f))
                FilterChip(selected = !p1080, onClick = { if (!live) p1080 = false }, label = { Text("720p") })
                Spacer(Modifier.width(8.dp))
                FilterChip(selected = p1080, onClick = { if (!live) p1080 = true }, label = { Text("1080p") })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (sysAudio) "Звук: система (игра + вставленное видео)" else "Звук: микрофон",
                    Modifier.weight(1f)
                )
                Switch(checked = sysAudio, onCheckedChange = { if (!live) sysAudio = it && Build.VERSION.SDK_INT >= 29 })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Записывать экран в файл", Modifier.weight(1f))
                Switch(checked = record, onCheckedChange = { if (!live) record = it })
            }

            HorizontalDivider()
            Text("Заставка и концовка", style = MaterialTheme.typography.titleMedium)
            FileRow("Заставка (перед стримом)", intro, { pickIntro.launch(arrayOf("video/*")) }, { intro = null }, !live)
            FileRow("Концовка (при остановке)", outro, { pickOutro.launch(arrayOf("video/*")) }, { outro = null }, !live)

            Button(
                onClick = {
                    if (url.isBlank() && !record) {
                        Toast.makeText(this@MainActivity, "Укажи RTMP-адрес или включи запись", Toast.LENGTH_LONG).show()
                    } else {
                        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
                        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
                        perms.launch(p.toTypedArray())
                    }
                },
                enabled = !live, modifier = Modifier.fillMaxWidth()
            ) { Text(if (url.isBlank()) "Начать запись экрана" else "Начать стрим") }

            Button(
                onClick = { startService(Intent(this@MainActivity, StreamService::class.java).setAction(StreamService.A_STOP)) },
                enabled = live, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) { Text("Остановить (с концовкой, если выбрана)") }

            HorizontalDivider()
            Text("Вставка видео в стрим", style = MaterialTheme.typography.titleMedium)
            Text("Любое видео — вертикальное или горизонтальное, пропорции сохраняются.", style = MaterialTheme.typography.bodySmall)
            FileRow("Видео для вставки", clip, { pickClip.launch(arrayOf("video/*")) }, { clip = null }, true)

            Text("Размер: ${size.toInt()}% кадра (100% = на весь экран)")
            Slider(value = size, onValueChange = { size = it }, valueRange = 10f..100f)

            val posNames = listOf("Центр", "Справа внизу", "Слева внизу", "Справа вверху", "Слева вверху")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.verticalScroll(rememberScrollState())) { }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                posNames.chunked(3).forEachIndexed { row, names ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        names.forEachIndexed { idx, n ->
                            val id = row * 3 + idx
                            FilterChip(selected = pos == id, onClick = { pos = id }, label = { Text(n) })
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Повторять по кругу", Modifier.weight(1f))
                Switch(checked = loop, onCheckedChange = { loop = it })
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        startService(
                            Intent(this@MainActivity, StreamService::class.java).setAction(StreamService.A_SHOW)
                                .putExtra("uri", clip.toString()).putExtra("size", size)
                                .putExtra("pos", pos).putExtra("loop", loop)
                        )
                    },
                    enabled = live && clip != null, modifier = Modifier.weight(1f)
                ) { Text(if (overlayOn) "Заменить" else "Показать в стриме") }
                OutlinedButton(
                    onClick = { startService(Intent(this@MainActivity, StreamService::class.java).setAction(StreamService.A_HIDE)) },
                    enabled = live && overlayOn, modifier = Modifier.weight(1f)
                ) { Text("Убрать") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    @Composable
    private fun FileRow(label: String, uri: Uri?, onPick: () -> Unit, onClear: () -> Unit, enabled: Boolean) {
        Column {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onPick, enabled = enabled) { Text("Выбрать") }
                Text(name(uri), Modifier.weight(1f), maxLines = 1)
                if (uri != null && enabled) TextButton(onClick = onClear) { Text("Сброс") }
            }
        }
    }
}
