package com.example.screenstream

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.view.Surface
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import com.pedro.encoder.input.gl.render.filters.`object`.SurfaceFilterRender
import com.pedro.encoder.utils.gl.TranslateTo
import com.pedro.library.rtmp.RtmpDisplay
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

object StreamBus {
    val live = MutableStateFlow(false)
    val overlay = MutableStateFlow(false)
    val status = MutableStateFlow("Готов")
}

class StreamService : Service() {

    companion object {
        const val A_START = "start"
        const val A_STOP = "stop"
        const val A_SHOW = "show"
        const val A_HIDE = "hide"
        private const val CH = "stream"
        private val POSITIONS = listOf(
            TranslateTo.CENTER, TranslateTo.BOTTOM_RIGHT, TranslateTo.BOTTOM_LEFT,
            TranslateTo.TOP_RIGHT, TranslateTo.TOP_LEFT
        )
    }

    private val main = Handler(Looper.getMainLooper())
    private var display: RtmpDisplay? = null
    private var player: MediaPlayer? = null
    private var videoFilter: SurfaceFilterRender? = null
    private var blackFilter: ImageObjectFilterRender? = null
    private var frameW = 0
    private var frameH = 0
    private var outroUri: Uri? = null
    private var recordFile: File? = null
    private var finishing = false

    private val checker = object : ConnectChecker {
        override fun onConnectionStarted(url: String) { StreamBus.status.value = "Подключение…" }
        override fun onConnectionSuccess() { StreamBus.status.value = "В эфире" }
        override fun onConnectionFailed(reason: String) {
            StreamBus.status.value = "Ошибка подключения: $reason"
            main.post { shutdown() }
        }
        override fun onNewBitrate(bitrate: Long) {}
        override fun onDisconnect() { StreamBus.status.value = "Отключено" }
        override fun onAuthError() { StreamBus.status.value = "Ошибка авторизации (ключ стрима)" }
        override fun onAuthSuccess() {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_START -> { startForegroundCompat(); start(intent) }
            A_STOP -> requestStop()
            A_SHOW -> {
                val uri = intent.getStringExtra("uri")?.let { Uri.parse(it) } ?: return START_NOT_STICKY
                val pct = intent.getFloatExtra("size", 40f)
                val pos = POSITIONS.getOrElse(intent.getIntExtra("pos", 0)) { TranslateTo.CENTER }
                val loop = intent.getBooleanExtra("loop", true)
                val full = pct >= 99.5f
                playVideo(uri, full, pct / 100f, pos, loop) { }
                StreamBus.overlay.value = true
            }
            A_HIDE -> { clearVideo(); StreamBus.overlay.value = false }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Стрим", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, StreamService::class.java).setAction(A_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("Screen Stream")
            .setContentText("Идёт запись экрана / стрим")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(Notification.Action.Builder(null, "Стоп", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                1, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else startForeground(1, n)
    }

    private fun start(i: Intent) {
        if (display != null) return
        finishing = false
        val code = i.getIntExtra("code", 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            i.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") i.getParcelableExtra("data")
        val w = i.getIntExtra("w", 720)
        val h = i.getIntExtra("h", 1280)
        val dpi = i.getIntExtra("dpi", 320)
        val br = i.getIntExtra("br", 3_500_000)
        val url = i.getStringExtra("url").orEmpty()
        val rec = i.getBooleanExtra("rec", false)
        val sysAudio = i.getBooleanExtra("sysAudio", false)
        val intro = i.getStringExtra("intro")?.let { Uri.parse(it) }
        outroUri = i.getStringExtra("outro")?.let { Uri.parse(it) }
        frameW = w; frameH = h

        if (data == null) { fail("Нет разрешения на захват экрана"); return }
        try {
            val d = RtmpDisplay(applicationContext, true, checker)
            d.setIntentResult(code, data)
            val videoOk = d.prepareVideo(w, h, 30, br, 0, dpi)
            val audioOk = if (sysAudio && Build.VERSION.SDK_INT >= 29)
                d.prepareInternalAudio(128 * 1024, 44100, true, false, false)
            else d.prepareAudio(128 * 1024, 44100, true, true, true)
            if (!videoOk || !audioOk) { fail("Не удалось подготовить кодеки"); return }
            display = d
            if (url.isNotBlank()) { StreamBus.status.value = "Подключение…"; d.startStream(url) }
            if (rec) {
                val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
                val f = File(dir, "screen_${System.currentTimeMillis()}.mp4")
                recordFile = f
                d.startRecord(f.absolutePath)
                if (url.isBlank()) StreamBus.status.value = "Идёт запись"
            }
            StreamBus.live.value = true
            if (intro != null) playVideo(intro, true, 1f, TranslateTo.CENTER, false) { }
        } catch (e: Exception) {
            fail("Ошибка запуска: ${e.message}")
        }
    }

    private fun fail(msg: String) {
        StreamBus.status.value = msg
        shutdown()
    }

    /** Показывает видео как слой в стриме. pct = доля кадра (0..1), видео вписывается с сохранением пропорций. */
    private fun playVideo(uri: Uri, full: Boolean, pct: Float, pos: TranslateTo, loop: Boolean, onDone: () -> Unit) {
        val d = display ?: return
        clearVideo()
        var vw = 0; var vh = 0; var rot = 0
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, uri)
            vw = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            vh = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
        } catch (_: Exception) { }
        if (rot == 90 || rot == 270) { val t = vw; vw = vh; vh = t }
        if (vw <= 0 || vh <= 0) { vw = 16; vh = 9 }
        val a = vw.toFloat() / vh
        val f = frameW.toFloat() / frameH
        val sx: Float; val sy: Float
        if (a >= f) { sx = pct * 100f; sy = pct * 100f * f / a } else { sy = pct * 100f; sx = pct * 100f * a / f }

        val mp = MediaPlayer()
        player = mp
        try {
            mp.setDataSource(this, uri)
        } catch (e: Exception) {
            StreamBus.status.value = "Не удалось открыть видео"
            clearVideo(); onDone(); return
        }
        mp.setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build()
        )
        mp.isLooping = loop
        mp.setOnCompletionListener {
            if (!loop && player === mp) main.post { clearVideo(); StreamBus.overlay.value = false; onDone() }
        }
        mp.setOnErrorListener { _, _, _ ->
            main.post { clearVideo(); StreamBus.overlay.value = false; onDone() }
            true
        }
        mp.setOnPreparedListener {
            if (player !== mp || display == null) return@setOnPreparedListener
            if (full) {
                val bf = ImageObjectFilterRender()
                d.glInterface.addFilter(bf)
                bf.setImage(Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLACK) })
                bf.setScale(100f, 100f)
                bf.setPosition(TranslateTo.CENTER)
                blackFilter = bf
            }
            val vf = SurfaceFilterRender { st ->
                try { mp.setSurface(Surface(st)); mp.start() } catch (_: Exception) { }
            }
            d.glInterface.addFilter(vf)
            vf.setScale(sx, sy)
            vf.setPosition(pos)
            videoFilter = vf
        }
        mp.prepareAsync()
    }

    private fun clearVideo() {
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        val d = display
        try { videoFilter?.let { d?.glInterface?.removeFilter(it) } } catch (_: Exception) { }
        try { blackFilter?.let { d?.glInterface?.removeFilter(it) } } catch (_: Exception) { }
        videoFilter = null
        blackFilter = null
    }

    private fun requestStop() {
        val d = display
        if (d == null || finishing) { shutdown(); return }
        val outro = outroUri
        if (outro != null) {
            finishing = true
            StreamBus.status.value = "Концовка…"
            playVideo(outro, true, 1f, TranslateTo.CENTER, false) { shutdown() }
        } else shutdown()
    }

    private fun shutdown() {
        clearVideo()
        val d = display
        display = null
        try { if (d?.isRecording == true) d.stopRecord() } catch (_: Exception) { }
        try { if (d?.isStreaming == true) d.stopStream() } catch (_: Exception) { }
        saveRecordToGallery()
        StreamBus.live.value = false
        StreamBus.overlay.value = false
        if (!StreamBus.status.value.startsWith("Ошибка")) StreamBus.status.value = "Готов"
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun saveRecordToGallery() {
        val f = recordFile ?: return
        recordFile = null
        if (Build.VERSION.SDK_INT < 29 || !f.exists() || f.length() == 0L) return
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ScreenStream")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: return
            contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            f.delete()
            StreamBus.status.value = "Запись сохранена: Movies/ScreenStream"
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        if (display != null) shutdown()
        super.onDestroy()
    }
}
