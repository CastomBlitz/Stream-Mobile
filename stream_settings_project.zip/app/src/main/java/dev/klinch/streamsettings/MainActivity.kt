package dev.klinch.streamsettings

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.pedro.streamer.stream.Stream
import com.pedro.streamer.stream.video.CameraSource
import com.pedro.streamer.stream.video.ScreenSource
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private lateinit var streamService: StreamService
    private var mediaProjection: MediaProjection? = null
    private var projectionResultCode = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        streamService = StreamService.getInstance(this)

        // Request permissions
        requestPermissionsIfNeeded()

        // Setup UI listeners
        findViewById<Button>(R.id.btn_start).setOnClickListener(startStreamClick)
        findViewById<Button>(R.id.btn_stop).setOnClickListener(stopStreamClick)
        findViewById<Button>(R.id.btn_platforms).setOnClickListener(selectPlatformsClick)
        findViewById<Button>(R.id.btn_settings).setOnClickListener(settingsClick)
        findViewById<Button>(R.id.btn_skimmer).setOnClickListener(showSkimmerClick)
    }

    private fun requestPermissionsIfNeeded() {
        val perms = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        val granted = perms.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        if (!granted) {
            ActivityCompat.requestPermissions(this, perms, 1001)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001) {
            val allGranted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (!allGranted) {
                finish()
            }
        }
    }

    private fun startStreamClick() {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Настройки стрима")
            .setMultiChoiceItems(
                arrayOf("YouTube", "Twitch", "TikTok", "Facebook", "Kick", "VK Live", "Trovo"),
                null,
                (dialogInterface, which, isChecked) -> {
                    // Handle selection
                }
            )
            .setPositiveButton("Начать") { _, _ ->
                startSelectedStream()
            }
            .create()
        dialog.show()
    }

    private fun startSelectedStream() {
        // Get checked platforms - simplified: start all selected
        val allPlatforms = arrayOf("YouTube", "Twitch", "TikTok", "Facebook", "Kick", "VK Live", "Trovo")
        val useCamera = true  // default
        val useScreen = true  // default
        val useMicrophone = true

        streamService.startStream(
            listOf(allPlatforms.filter { it == "YouTube" || it == "Twitch" || it == "TikTok" || it == "Facebook" || it == "Kick" || it == "VK Live" || it == "Trovo" }),
            useCamera,
            useScreen,
            useMicrophone
        )
    }

    private fun stopStreamClick() {
        streamService.stopStream()
        Toast.makeText(this, "Стрим остановлен", Toast.LENGTH_SHORT).show()
    }

    private fun selectPlatformsClick() {
        // Show platform selection dialog
        val dialog = AlertDialog.Builder(this)
            .setTitle("Выбрать платформы")
            .setMultiChoiceItems(
                arrayOf("YouTube", "Twitch", "TikTok", "Facebook", "Kick", "VK Live", "Trovo"),
                null,
                (dialogInterface, which, isChecked) -> {}
            )
            .setPositiveButton("OK") { _, _ -> }
            .create()
        dialog.show()
    }

    private fun settingsClick() {
        // Open settings screen
        val intent = Intent(this, SettingsActivity::class.java)
        startActivity(intent)
    }

    private fun showSkimmerClick() {
        // Show gift scrimmer
        showGiftSkimmer("Подарок!", "Пользователь подарил подарок")
    }

    fun showGiftSkimmer(title: String, text: String) {
        val layout = LayoutInflater.from(this).inflate(R.layout.skimmer, null)
        layout.findViewById<TextView>(R.id.skimmer_title).text = title
        layout.findViewById<TextView>(R.id.skimmer_text).text = text

        val wm = getSystemService(WindowManager::class.java) as WindowManager
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            android.graphics.PixelFormat.TRANSPARENT
        )
        params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL
        params.y = -100  // Start above screen

        wm.addView(layout, params)

        // Animate up
        val handler = Handler()
        handler.postDelayed {
            val anim = ObjectAnimator.ofFloat(layout, "y", -100f, 0f)
            anim.duration = 500
            anim.start()
        }

        // Auto dismiss after 3 seconds
        Handler().postDelayed { layout.destroyView() }, 3000
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1002 && resultCode == Activity.RESULT_OK && data != null) {
            mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data)
            // Initialize screen source with the media projection
        }
    }

    private val mediaProjectionManager: MediaProjectionManager =
        getSystemService(MediaProjectionManager::class.java)
}