package dev.klinch.streamsettings

import android.app.ForegroundService
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.os.Build
import android.util.Log
import com.pedro.streamer.stream.Stream
import com.pedro.streamer.stream.video.CameraSource
import com.pedro.streamer.stream.video.ScreenSource
import com.pedro.streamer.stream.audio.MicrophoneSource
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class StreamService : ForegroundService() {

    private var stream: Stream? = null
    private var isRunning = false
    private val platforms = mutableListOf<PlatformConfig>()
    private val scheduled = Executors.newSingleThreadScheduledExecutor()

    data class PlatformConfig(
        val name: String,
        val server: String,
        val streamKey: String,
        val enabled: Boolean = true
    )

    override fun onCreate() {
        super.onCreate()
        // Initialize default platforms
        platforms.add(PlatformConfig("YouTube", getString(R.string.youtube_server), ""))
        platforms.add(PlatformConfig("Twitch", getString(R.string.twitch_server), ""))
        platforms.add(PlatformConfig("TikTok", getString(R.string.tiktok_server), ""))
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        val action = intent.action
        return when (action) {
            -> super.onStartCommand(intent, flags, startId)
        }
    }

    fun startStream(
        platformNames: List<String>,
        useCamera: Boolean,
        useScreen: Boolean,
        useMicrophone: Boolean
    ) {
        if (isRunning) return

        val enabledPlatforms = platforms.filter { it.name in platformNames && it.enabled }

        if (enabledPlatforms.isEmpty()) {
            Log.e("StreamService", "No enabled platforms selected")
            return
        }

        // Limit to 3 platforms max
        val selected = enabledPlatforms.take(3)

        isRunning = true
        startForegroundServiceIntent()

        // Create stream sources
        val cameraSource = if (useCamera) CameraSource(this) else null
        val screenSource = if (useScreen) ScreenSource(this) else null
        val micSource = if (useMicrophone) MicrophoneSource(this) else null

        scheduled.execute {
            try {
                val streams = selected.map { platform ->
                    Stream(this)
                        .setVideoSource(buildVideoSource(cameraSource, screenSource))
                        .setAudioSource(buildAudioSource(micSource))
                        .setPreview(previewView = null) // will be set by activity
                        .setBps(bitrateToBits(bitrate))
                        .setFps(fps)
                        .setVideoResolution(videoResolution)
                        .setServer(platform.server)
                        .setStreamKey(platform.streamKey)
                        .build()
                }

                // Start all streams
                streams.forEach { it.start() }

                // Keep reference to first stream for management
                this.stream = streams.firstOrNull()
            } catch (e: Exception) {
                Log.e("StreamService", "Failed to start stream", e)
                isRunning = false
            }
        }
    }

    private fun buildVideoSource(cameraSource: CameraSource?, screenSource: ScreenSource?): Int {
        if (cameraSource != null && screenSource != null) {
            // Both camera and screen - use combined source
            return 1 /* combined mode */  // RootEncoder handles PIP mode
        } else if (cameraSource != null) {
            return cameraSource.hashCode()
        } else if (screenSource != null) {
            return screenSource.hashCode()
        }
        return 0
    }

    private fun buildAudioSource(micSource: MicrophoneSource?): Int {
        return micSource?.hashCode() ?: 0
    }

    fun stopStream() {
        isRunning = false
        scheduled.execute {
            try {
                stream?.let { it.stop() }
                stream?.let { it.release() }
                stream = null
                stopForeground(true)
            } catch (e: Exception) {
                Log.e("StreamService", "Failed to stop stream", e)
            }
        }
    }

    private fun startForegroundServiceIntent() {
        val channelId = "stream_service_channel"
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("StreamSettings — стрим активен")
            .setContentText("Запись экрана и камеры")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = android.app.NotificationChannel(
                channelId,
                "StreamService",
                android.app.NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        startForeground(1, notification)
    }

    // Settings
    var bitrate: Int = 2500  // 2500 Kbps default
    var fps: Int = 30
    var videoResolution: String = "720p"

    override fun onDestroy() {
        stopStream()
        super.onDestroy()
    }
}