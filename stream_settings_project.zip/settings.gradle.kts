rootProject.name = "StreamSettings"
include(":app")